module leddecoder (char, led);
    input [3:0] char;
    output reg [6:0] led; // led = ABCDEFG

    always @(char) begin 
        case (char)
            4'b0000: led = 7'b0000001; // 0
            4'b0001: led = 7'b1001111; // 1
            4'b0010: led = 7'b0010010; // 2
            4'b0011: led = 7'b0000110; // 3
            4'b0100: led = 7'b1001100; // 4
            4'b0101: led = 7'b0100100; // 5
            4'b0110: led = 7'b0100000; // 6
            4'b0111: led = 7'b0001111; // 7
            4'b1000: led = 7'b0000000; // 8
            4'b1001: led = 7'b0000100; // 9
            4'b1010: led = 7'b0000010; // A
            4'b1011: led = 7'b1100000; // b
            4'b1100: led = 7'b0110001; // c
            4'b1101: led = 7'b1000010; // d
            4'b1110: led = 7'b0010000; // E
            4'b1111: led = 7'b0111000; // F
            default: led = 7'b1111111;
        endcase    
    end
endmodule
